To load a custom widget library, choose “Load Library” from the dropdown menu in the Widgets pane toolbar and browse to the .rplib file. After loading the library, it will appear in the Widgets pane and you can drag and drop them onto the wireframe as normal.

To automatically load the library each time you start Axure RP, save the .rplib file in the ~/My Documents/My Axure RP Libraries folder on your PC, or ~/Documents/Axure/Libraries on your Mac. Axure RP will also attempt to load libraries saved elsewhere if they have been previously loaded.

To unload a library, choose “Unload library” from the dropdown menu in the Widgets pane toolbar and it will remove the library from the Widgets pane.
